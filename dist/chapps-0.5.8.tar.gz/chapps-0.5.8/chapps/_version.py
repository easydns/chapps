__version__ = "0.5.8"
f"""Current CHAPPS version is {__version__}"""
