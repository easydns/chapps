"""chapps.util

These are the utility classes for CHAPPS
"""
from collections.abc import Mapping
import re

class AttrDict():
    """This simple class allows accessing the keys of a hash as attributes on an object.  As a useful side effect it also casts floats and integers in advance.  This object is used for holding the configuration data."""
    boolean_pattern = re.compile('^[Tt]rue|[Ff]alse$')
    def __init__(self, data={}):
        for k, v in data.items():
            if k[0:2] != '__':
                val = v
                try:
                    val = int(v)
                except ValueError:
                    try:
                        val = float(v)
                    except ValueError:
                        m = self.boolean_pattern.match(v)
                        if m:
                            val = (m.span(0)[1] == 4) # if the match is 4 chars long, it is True
                setattr(self, k, val)

class PostfixPolicyRequest(Mapping):
    """An implementation of Mapping which by default only processes and caches values from the data payload when they are accessed, to avoid a bunch of useless parsing."""
    def __init__(self, payload):
        """We get passed a payload of strings which are formatted as 'key=val'"""
        self._chapps_payload = payload[0:-2]

    def __getattr__(self, attr, dfl=None):
        """Overload in order to search for missing attributes in the payload"""
        line = next(( l for l in self._chapps_payload if attr in l ), None)
        if line:
            key, value = line.split("=")
            setattr(self, key, value)
            return value
        return None

    def __getitem__(self, key):
        """Getting an item should optimize the result via the attribute mechanism"""
        return getattr(self, key)

    def __iter__(self):
        """Return an iterable representing the mapping"""
        if not getattr(self, '_chapps_mapping', None):
            self._chapps_mapping = { k: v for k,v in [ l.split("=") for l in self._chapps_payload ] }
            # Since we end up parsing the entire payload, optimize it for future random access
            for k, v in self._chapps_mapping.items():
                setattr(self, k, v)
        yield from self._chapps_mapping


    def __len__(self):
        """Act like a dict and return the number of k,v pairs"""
        return len(self._chapps_payload)

    @property
    def recipients(self):
        """A convenience method to split the 'recipient' datum into comma-separated tokens, for easier counting."""
        if not self._recipients:
            self._recipients = self.recipient.split(',') if self.recipient and len(self.recipient) > 0 else []
        return self._recipients
