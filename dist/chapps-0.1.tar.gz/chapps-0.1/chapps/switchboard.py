"""chapps.switchboard

Message multiplexing objects and/or routines for CHAPPS
"""
from .config import config
from .policy import OutboundQuotaPolicy, GreylistingPolicy
from .util import AttrDict, PostfixPolicyRequest
from .tests.conftest import CallableExhausted
import logging, chapps.logging
import asyncio

logger = logging.getLogger(__name__) # pragma: no cover
logger.setLevel( logging.DEBUG )     # pragma: no cover
logger.debug( "Request library initialized." )

class RequestHandler():
    """Wrap handling in an object-oriented factory so we can supply a policy"""
    def __init__(self, policy):
        self.policy = policy
        self.config = self.policy.config # in case a custom config is in use

    def async_policy_handler(self):
        """Returns a coroutine which handles requests according to the policy"""
        logger.debug(f"Policy handler requested for {type(self.policy).__name__}.")
        policy = self.policy
        accept = self.config.policy.acceptance_message
        reject = self.config.policy.rejection_message
        encoding = config.chapps.payload_encoding
        async def handle_policy_request(reader, writer) -> None:
            """Handles reading and writing the streams around policy approval messages"""
            while True:
                try:
                    policy_payload = await reader.readuntil(b'\n\n')
                except ConnectionResetError:
                    logger.debug("Postfix said goodbye. Terminating this thread.")
                    return
                except CallableExhausted as e:
                    raise e
                except Exception:
                    logger.exception("UNEXPECTED ")
                    if reader.at_eof():
                        logger.debug("Postfix said goodbye oddly. Terminating this thread.")
                        return
                    continue
                logger.debug(f"Payload received: {policy_payload.decode('utf-8')}")
                policy_data = PostfixPolicyRequest( policy_payload.decode(encoding).split('\n') )
                if policy.approve_policy_request(policy_data):
                    resp = ("action=" + accept + "\n\n").encode()
                    logger.debug(f"  .. Accepted.  Sending {resp}")
                else:
                    resp = ("action=" + reject + "\n\n").encode()
                    logger.debug(f"  .. Rejected with {resp}")
                try:
                    writer.write( resp )
                except asyncio.CancelledError: # pragma: no cover
                    pass
                except Exception:
                    logger.exception(f"Exception raised trying to send {resp}")
                    return
        return handle_policy_request

class OutboundQuotaHandler(RequestHandler):
    def __init__(self, policy=None):
        p = policy if policy else OutboundQuotaPolicy()
        super().__init__( p )
        self.config.policy = self.config.policy_oqp # setup for outbound quota

class GreylistingHandler(RequestHandler):
    def __init__(self, policy=None):
        p = policy if policy else GreylistingPolicy()
        super().__init__( p )
        self.config.policy = self.config.policy_grl # setup for greylisting
