"""CHAPPS

Caching, Highly-Available Postfix Policy Service

This package contains the following modules:
    util -- utility functions
"""
__all__ = [ 'util' ]
