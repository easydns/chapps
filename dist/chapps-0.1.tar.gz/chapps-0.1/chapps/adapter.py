"""Policy-configuration source data adapters"""
import mariadb
import logging, chapps.logging

logger = logging.getLogger(__name__)                              # pragma: no cover

class MariaDBQuotaAdapter():
    """A class for adapting to MariaDB for quota policy data"""
    quota_table = ("CREATE TABLE IF NOT EXISTS quotas ("          # pragma: no cover
                    "id bigint auto_increment primary key,"
                    "name varchar(32) unique not null,"
                    "quota bigint unique not null"
    ")")
    join_table = ("CREATE TABLE IF NOT EXISTS quota_user ("       # pragma: no cover
                   "quota_id bigint not null,"
                   "user varchar(128) not null primary key"
                   ")")
    basic_quotas = ("INSERT INTO quotas ( name, quota ) VALUES "  # pragma: no cover
                    "('10eph', 240),"
                    "('50eph', 1200),"
                    "('200eph', 4800)")
    quota_query = "SELECT quota FROM quotas WHERE id = (SELECT quota_id FROM quota_user WHERE user = %(user)s)" # pragma: no cover
    quota_map_query = "SELECT user, quota FROM quotas AS p LEFT JOIN (quota_user AS j) ON (p.id = j.quota_id)"  # pragma: no cover
    quota_map_where = "WHERE user IN ({srch})"                    # pragma: no cover

    def __init__(self, *, db_host, db_port=3306, db_name=None, db_user, db_pass, autocommit=True):
        self.host = db_host
        self.db = db_name
        self.user = db_user
        kwargs = dict(
            user = db_user,
            password = db_pass,
            host = db_host,
            port = int(db_port),
            autocommit = autocommit
        )
        if db_name:
            kwargs['database'] = db_name
        self.conn = mariadb.connect( **kwargs )

    def _initialize_tables(self):
        cur = self.conn.cursor()
        cur.execute( self.quota_table )
        cur.execute( self.join_table )
        cur.execute( "SELECT COUNT(name) FROM quotas" )
        if (cur.fetchone()[0] == 0):
            cur.execute( self.basic_quotas )
        cur.close()

    def finalize(self):
        self.conn.close()

    def quota_for_email(self, email):
        """Return the quota for an email address"""
        cur = self.conn.cursor()
        cur.execute( self.quota_query, dict(user=email) )
        try:
            res = cur.fetchone()[0]
        except TypeError:         ### generally meaning no result; we could log this
            res = None
        except mariadb.Error as e:# pragma: no cover
            logger.error(e)       ### CUSTOMIZE: log-level
            res = None
        finally:
            cur.close()
        return res

    def _quota_search(self, emails=[]):
        cur = self.conn.cursor()
        if len(emails) == 0:
            query = self.quota_map_query
            cur.execute( query )
        else:
            query = self.quota_map_query + " " + self.quota_map_where
            srch = str(emails)[1:-1]    ### TODO: some part of this will break
            cur.execute( query.format(srch=srch) )
        return cur.fetchall()

    def quota_dict(self, emails=[]):
        """Return a dict which maps emails onto their quotas"""
        rows = self._quota_search( emails )
        res = { r[0]: r[1] for r in rows }
        return res

    def quota_map(self, func, emails=[]):
        """Provide a function to execute over each email and its quota.  Use this to directly wire the database-loading logic to the Redis-population logic."""
        if not callable(func):
            raise ValueError( "The first non-self argument must be a callable which accepts the email and quota as arguments, in that order." )
        rows = self._quota_search( emails )
        res = []
        for row in rows:
            res.append( func( row[0], row[1] ) )
        return res
