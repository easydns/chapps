# CHAPPS

## the Caching, Highly-Available Postfix Policy Service

### requires Python 3.8.10+
### makes use of Redis, (eventually Sentinel) and a relational database (MariaDB)

## Introduction

There is a need for a highly-available, high-performance, concurrent, clusterable solution for handling various
aspects of email policy.  Postfix farms out the job of policy decisions to a delegate over a socket, so we can
provide a framework for receiving that data, making a decision about it, and then sending a response back to Postfix.
There are some projects which have provided smaller-scale solutions to this issue.  We handle rather a large volume
of email, so we need something more performant than a script which makes a database access on every email.

My decision was to use Redis, since with Redis Sentinel it should be possible to achieve a degree of high-availability
using Redis as a common datastore between the various email servers in the farm(s) which will run local instances of
the policy server, which will itself use Redis to cache data and keep track of email quotas, etc.

In the first iteration, we propose to provide functionality for:
 - outbound quota tracking on a continuous, rolling, per-interval basis;
 - inbound email greylisting;
 - inbound SPF checking

The framework is meant to be extensible, so that any conceivable email policy might be implemented in the future.

The library will create a config file for itself if does not find one at its default config path,
`/etc/chapps/chapps.ini`, or the value of
the environment variable `CHAPPS_CONFIG` if it is set.  Note that default settings for all available submodules
will be produced.  At the time of writing, each script runs its own type of policy handler, so only the settings
for that policy will be needed, plus the general CHAPPS settings and the Redis settings.

Example Postfix configs are included in the `postfix` directory, classified by which service they are for.  Most
access control policy services will be implemented in a very similar way in `main.cf`, probably in combination
with other policies.  The examples provided are the same configs used for testing, and are necessarily stripped
down to focus just on that particular service.

Installation artifacts are available
in the `install` directory, including a shell script to copy things to their places, and the SystemD service
files for starting the outbound quota and greylisting services.

PLEASE NOTE: At present, the configured port number is not attached to a particular service, and this means that
**only one service may run at once**, until the port configuration is factored into the policy config.

## Outbound Quota Policy Service

The service is designed to run locally side-by-side with the Postfix server, and connect to a remote or local
Redis instance,
possibly via Sentinel.  As such it listens on 127.0.0.1, and on port 11511 by default, though both may be adjusted
in the config file.  It obtains quota policy data on a per-sender-email basis, from a relational database, and
caches that data in Redis for operational use.  Once a user's quota data has been stored, it will be cached for
a day, so that database accesses may be avoided.  Current quota usage is not kept in a relational database.

In order to set up Postfix for policy delegation, consult
[Postfix documentation](http://www.postfix.org/SMTPD_POLICY_README.html) to gain a complete understanding
of how policy delegation works.  In short, the `smtpd_recipient_restrictions` block should contain the setting
`check_policy_service inet:127.0.0.1:11511`.  In addition, it is necessary to ensure that the service itself,
the script `chapps_outbound_quota.py` is running.  This should be accomplished using `systemd` or similar;
scripts/file assets to assist with that will be added soon.  For now, as I understand it, Postfix's own `spawn`
functionality from `master.cf` should be avoided.

### Outbound Quota Policy Configuration: Database Setup

At present, the service expects to obtain quota policy enforcement parameters from a relational database, in
particular, MariaDB.  The framework has been designed to make it easy to write adapters to any particular
backend datasource regarding quota information.

The database schema used has been kept as simple as possible:
```
       Table: quotas
Create Table: CREATE TABLE `quotas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `quota` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `quota` (`quota`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4

       Table: quota_user
Create Table: CREATE TABLE `quota_user` (
  `quota_id` bigint(20) NOT NULL,
  `user` varchar(128) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
```
The `quotas` table contains quota-profiles, records with an auto-increment ID,
and the `name` and quota-limit (`quota`) of that quota-profile.

The `quota_user` table is meant as a join table on possible external databases.
The `quota_user.user` column is meant to contain an email address, the sender address the quota applies to.

TODO: Looking at the schema dumps above, it occurs to me that the join-table should probably have an index over
both columns.

Once the `quotas` table has been populated with the desired quota policies, the `quota_user` table may then
be populated to reflect each user's quota.

The application sets cached quota limit data to expire after 24 hours, so it will occasionally refresh quota
policy settings, in case they get changed.  In order to flush the quota information, all that is required is
to delete that user's policy tracking data from Redis.  TODO: A tool will be provided to do this.

**Please note:** Users with no policy entry will not be able to send outbound email.

### Redis Configuration

Redis is used to store the real-time state of every active user's outbound quota.  An active user is one who
has sent email in the last _interval_, that interval defaulting to a day, since most quotas are expressed as
messages-per-day.  If your Redis deployment is non-standard, or if CHAPPS is sharing a Redis instance with some
other services, it may be necessary to adjust the Redis-related settings in the config file, to adjust the
address and/or port to connect to, or what database to use.

If Sentinel is in use, be sure to specify the IP address of the Sentinel master in the `sentinel_master`
parameter of the Redis section of the INI file.  In such a case it should not be necessary to specify a
server address.

## Greylisting Policy Service
