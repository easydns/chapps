# CHAPPS Installation

## A work in progress

### CHAPPS Services

Right now only one service may run at a time due to port-configuration inflexibility which will be addressed
in a future version.  The existing state of the software is sufficient for evaluation of its basic fitness.

CHAPPS tools are generally meant to run as a service (daemon), and thus managed by SystemD or supervisord.
Since I am working in a Debian environment, with SystemD, that is what I am aiming to support first.

Right now, I am going to provide a SystemD profile which can be copied to the appropriate location on your
system; for me that location is `/usr/lib/systemd/system`

Until the package is coming down from PyPI, it will be necessary to choose a location to place the git repo,
then make a copy of the SystemD profile and modify it to reflect the proper path to the scripts.  In addition,
the Python package (library) itself will need to be placed in a location which puts it in the Python search
path, or a virtualenv can be used (though there are some tricks to doing this with a service.)

Ideally, the whole thing gets installed by PyPI, and then tho' the paths to the scripts may be weird, they
will be known and can be substituted into the SystemD profile template during installation.

In bullet points:
- the library must be in the Python search path
- the script must be executable, and its path must be correct in the SystemD profile
- the SystemD profile needs to go into a place where SystemD will find it and act on it

Optionally:
- modify your Postfix service profile to add a `Requires=` line to ensure that the policy service is running
  before Postfix starts; we use RequiredBy= so this isn't strictly necessary.
