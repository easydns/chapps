__version__ = "0.5.9"
f"""Current CHAPPS version is {__version__}"""
