__version__ = "0.5.15"
f"""Current CHAPPS version is {__version__}"""
